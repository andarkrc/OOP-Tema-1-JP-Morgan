package org.poo.utils;

public final class Constants {
    public static final int WARNING_AMOUNT = 30;

    private Constants() {

    }
}
