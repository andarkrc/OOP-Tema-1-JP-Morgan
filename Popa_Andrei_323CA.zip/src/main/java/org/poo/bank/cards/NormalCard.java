package org.poo.bank.cards;

public final class NormalCard extends Card {
    public NormalCard(final String cardNumber) {
        super(cardNumber);
    }
}
